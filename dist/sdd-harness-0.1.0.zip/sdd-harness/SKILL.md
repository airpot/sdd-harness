---
name: sdd-harness
description: Use when specification-driven development spans multiple changes, chats, worktrees, machines, or coding agents; when resuming a task, reconciling acceptance evidence, preparing a release, or recovering and retiring a project worktree.
metadata:
  version: "0.1.0"
---

# SDD Harness

让需求、改动、证据和交接保持一致。以可安装的 skill 工作，复用项目已有 Git、规格和宿主工具；不把使用 skill 扩成建设管理平台。

## 进入项目

1. 读取当前用户目标、项目指令、已有规格入口和相关任务交接；保留已有授权。只加载当前任务相关材料。
2. 写入前识别仓库、实际 worktree、分支、当前改动及活动使用者。可运行随包脚本的 `inspect`，也要核对宿主会话、后台任务和任务归属。
3. 新窗口误入忙碌或归属不明的工作区时，先读取固定成果或分配独立工作区。`git status clean`、心跳过期、窗口关闭都不证明无人使用。

脚本路径相对于本 skill 目录，执行时解析为实际绝对路径。项目状态写入目标项目，不能写在 skill 安装目录。

## 开发循环

采用 OpenSpec 的已接受规格与增量变更思路，结合 Spec Kit 的澄清、原则检查和一致性分析；无需安装两套工具。

- 找到已接受的需求、相关接口和已知基线行为。已有规格与任务直接引用，不重建平行清单。
- 为本次范围写出可观察的验收条件、相关依赖和下一项可验证改动；小任务不强制生成整套文档。
- 按依赖允许并行，使用独立工作区及运行资源。共享接口、数据结构或依赖变化应通知相关任务并重审受影响证据。
- 小批实现、核对实际差异、执行适当验证、尽早集成。测试通过只证明其覆盖范围；保持“未执行”“受阻”“失败”可见。
- 规格调整先标明提议和原因，按项目现有规则接受。不能为了让实现通过而静默降低验收条件。

完整流程按需读 [references/workflow.md](references/workflow.md)。

## 接续与协作

任务属于项目，执行窗口、机器或模型可以更换。正常交接保存成果并停止原写入；新执行者核对实际状态后接手。

- 保存目标、规格和代码版本、成果位置、有效证据、关键决定、未完成事项和具体下一步。使用 [assets/handoff.md](assets/handoff.md)。
- 跨机器传递提交或可恢复快照、必要产物及校验信息。旧机器路径不是可访问成果；必要成果缺失时只继续不依赖它的工作。
- 原执行者无法确认停止时，新执行者使用独立工作区。旧成果保留供评估，不自动覆盖当前决定或发布。
- 本地登记和 Git 中的交接文件用于观察与沟通，不是分布式锁。强制认领或发布排他复用已验证的宿主、任务系统或 CI 能力；不默认自造共享锁协议。

涉及多执行者时读 [references/collaboration.md](references/collaboration.md)。

## 验收与发布

核对需求覆盖、实际差异、相关依赖和证据。证据绑定确切提交或快照、规格版本及相关环境；对象变化后重新判断适用性。

开发资格、集成资格和发布授权分别核对。用户已经授权的常规动作继续完成；skill 本身不扩大授权范围。

发布通过项目既有入口，固定候选提交、产物与环境，确认相关组合验证及发布负责人。存在竞争或未决发布时核对实际系统，不能凭本地通过就直接部署。取消和超时不自动代表回滚或失败。读 [references/delivery.md](references/delivery.md)，必要时使用 [assets/release.md](assets/release.md)。

## 收尾与可恢复回收

提交、任务验收、发布成功、工作区回收和聊天归档分别判断。

用户已授权自动回收时，归属明确、确认无人使用且必要成果可靠保存后自动执行，不逐个重新确认。只有对应资源存在未知归属、活动使用或成果保存缺口时阻塞回收，其他工作可继续。

优先用宿主原生可恢复归档。通用脚本提供 `snapshot`、`verify`、`restore`，不删除源目录，也不证明进程停止。保存后的核对和实际移除之间必须保持资源保护；具备可靠宿主入口后按 [references/recovery.md](references/recovery.md) 完成移除。无法维持保护时保留目录并说明缺口。

## 按需资源

| 当前需要 | 读取或运行 |
| --- | --- |
| 安装到其他 agent / 首次调用 | [references/install.md](references/install.md)；`scripts/install.py` |
| 从零开发或既有系统变更 | [references/workflow.md](references/workflow.md)；[assets/change.md](assets/change.md) |
| 多窗口 / 跨机器 / 跨 agent | [references/collaboration.md](references/collaboration.md) |
| 检查工作区和保存恢复 | `scripts/workspace.py --help`；[references/recovery.md](references/recovery.md) |
| 验收、集成和发布 | [references/delivery.md](references/delivery.md) |

结束时简述完成内容、验证依据、未验证范围与接续位置。不要把完成模板或生成更多文档作为完成任务的替代品。
