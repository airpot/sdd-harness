# 安装与使用

这是可直接复制的独立 skill，入口是 `sdd-harness/SKILL.md`。解压发行 ZIP 后，复制整个目录到目标 agent 的 skills 目录即可。随包脚本使用 Python 3.10+ 标准库；工作区工具另需 Git 2.29+。仅使用指令和模板不要求 Python。

## 安装

从解压目录执行以下命令之一；安装器仅复制文件，不改全局配置，不连接外部服务，不安装依赖。

```text
# Codex 用户级安装
python sdd-harness/scripts/install.py --into "~/.agents/skills"

# ZCode 用户级安装
python sdd-harness/scripts/install.py --into "~/.zcode/skills"

# DeepSeek Harness 项目级安装：在目标项目根目录执行，提供包的实际路径
python /path/to/sdd-harness/scripts/install.py --into "./.dsh/skills"
```

Python 启动命令在 Windows 也可替换为 `py -3`。`--into` 指 skills 父目录，安装器会在其下创建 `sdd-harness`。已存在且相同的包视为已安装；有本地修改或不同内容时拒绝覆盖。更新前将旧目录移到可恢复备份，再重新安装。

DeepSeek Harness 用户级目录是其实际配置的 `<dshHome>/skills`；也可以把项目包放到项目 `.agents/skills`。使用实际配置路径，不猜测用户自定义 Harness home。不同 profile 的 skill provider 需要已启用。

没有 Python 时手工复制完整目录；不要只复制 SKILL.md。复制版本不自动同步，跨机器每台安装同一版本，项目资料通过既有仓库和授权的成果存储同步。

## 发现和调用

- Codex：在可发现的 skills 目录安装后调用 `$sdd-harness`；未出现时核对来源和禁用设置，并刷新或重新启动会话。
- ZCode：Settings → Skills 刷新，确认来源与启用状态；可明确选择 `sdd-harness`。
- DeepSeek Harness：确认实际 profile 的 skill provider 和目录，明确加载 `sdd-harness`。

第一次在项目中调用：

> 使用 sdd-harness 处理本项目。先核对规格、当前任务和 worktree，再完成本次目标；复用已有资料，保留必要交接。

接续：

> 使用 sdd-harness 从任务交接继续。核对现有成果、责任归属和证据，完成下一项工作。

自动选择依赖宿主发现和模型判断，不保证每个新窗口必然自动调用。需要固定项目入口时，可在项目 AGENTS.md 中追加简短指引，保留已有指令。包不自动安装 hooks。

## 已验证的边界

发行包使用同一套指令和资源，安装器和工作区脚本做可迁移性测试。三款产品的发现路径依据当前官方资料；不能把文件复制成功当作各产品端到端执行已经验证。

skill 提供流程、记录和调用指引。它本身不提供跨机器分布式锁、进程强制停止或发布凭据隔离；相关保证取决于项目已有入口，并在使用时核对。

官方资料（查阅于 2026-10-05）：[Codex Skills](https://learn.chatgpt.com/docs/build-skills)、[ZCode Skill](https://zcode.z.ai/en/docs/skill)、[DeepSeek Harness Skills](https://github.com/deepseek-ai/deepseek-harness/blob/master/docs/subsystems/skills.md)。
