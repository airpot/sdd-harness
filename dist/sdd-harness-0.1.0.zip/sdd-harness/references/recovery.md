# 保存、恢复与回收

## 首选宿主原生归档

宿主具有可恢复 worktree 归档工具时，核对其能力、管理归属、保护资源、活动会话与必要成果；满足用户已授权政策后使用该工具，并核对归档与移除结果。

Codex app 若提供 `list_artifacts` / `archive_worktree`，按实际返回的身份使用，不以路径猜测附件身份。其保存范围不足以覆盖必要忽略文件或工作区外成果时，先独立保存并验证。其他 harness 也只使用其实际存在的工具，不假造工具名。

## 通用脚本

Python 3.10+、Git 2.29+；无第三方 Python 依赖。运行路径需替换为已安装 skill 的实际路径。

```text
python <skill-dir>/scripts/workspace.py inspect --repo <worktree>
python <skill-dir>/scripts/workspace.py snapshot --repo <worktree> --output <outside-worktree>/task.zip --include <necessary-ignored-path>
python <skill-dir>/scripts/workspace.py verify --archive <outside-worktree>/task.zip
python <skill-dir>/scripts/workspace.py restore --archive <outside-worktree>/task.zip --output <new-directory>
```

`inspect` 为只读观察，不能证明无人使用或授予写入权。

`snapshot` 保存当前 HEAD 的 Git bundle、Git 对象格式、当前存在的跟踪文件与普通未跟踪文件、跟踪文件删除清单，以及显式 `--include` 的忽略文件/目录。输出必须在工作区外且不覆盖已有文件。记录文件摘要与源状态，核对复制期间可观察变化；它仍不替代停止写入。

必要忽略成果须逐项选择。工作区外成果另行保存，记录可获取位置。脚本不自动同步远端，也不自动收集全部忽略目录或凭据。

`verify` 校验完整成员集合和内容摘要。`restore` 只写入新目录，恢复 HEAD 和文件状态，再输出结果；不恢复原生聊天、精确暂存区、其他分支、原机器路径、进程、凭据或外部数据库。接续后重新核对环境和证据，旧所有权记录不授予权限。

通用脚本拒绝 symlink、gitlink/submodule 和不支持的路径，避免错误承诺完整恢复；这类项目用具备对应保存能力的原生工具。验证摘要只说明内容一致，不证明外部来源可信。

## 实际移除

通用脚本不删除源目录。移除必须满足：

1. 归属及规范化绝对路径明确，确在授权受管临时资源范围；不是主工作区或永久环境。
2. 全部相关会话、写入和后台执行已核对停止。超时或没有发现已知进程不足以证明这一条件。
3. 必要成果可靠保存、可获取；重要恢复首次实际验证到独立目录，之后按项目既有恢复验证政策执行。
4. 保护资源，避免新会话在核对和移除间再次使用。保存后变化需重新保存验证。
5. 调用宿主原生移除或其支持的 Git worktree 移除方式；核对目录及登记状态。不要用递归强删代替 worktree 生命周期管理。

归档成功但移除失败时保留保存记录，继续同一操作；不要覆盖唯一备份。移除后状态写回失败，先查现场再补记录。未知归属、仍在使用或必要成果未保存时保留资源并说明原因。

任务尚待集成但已可靠保存，闲置工作区可以释放。工作区回收不自动归档聊天，也不等于发布成功。
